//
//  HourWeatherView.swift
//  CWK2Template
//
//  Created by girish lukka on 02/11/2023.
//

import SwiftUI

struct HourWeatherView: View {
    var current: Current

    var body: some View {
        let formattedDate = DateFormatterUtils.formattedDateWithDay(from: TimeInterval(current.dt))
        VStack() {
            Text(formattedDate)
                .padding(.top)
                .font(.title2)
                .padding(.horizontal)
                .foregroundColor(.black)

            AsyncImage(url: URL(string: "https://openweathermap.org/img/wn/\(current.weather[0].icon)@2x.png"))
            Text("\((Int)(current.temp))ºC")
                .foregroundColor(.black)
                .font(.system(size: 25))
            Text("\(current.weather[0].weatherDescription.rawValue.capitalized)")
                .padding(.bottom)
                .multilineTextAlignment(.center)
                .font(.system(size: 18))



        }
        .bold()
        .frame(width: 150, height: 225)
        .background(RoundedRectangle(cornerRadius: 25)
        .fill(.white)
        .opacity(0.4)
        .shadow(radius: 10.0))
                
    }
}





