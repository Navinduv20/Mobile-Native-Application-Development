//
//  DailyWeatherView.swift
//  CWK2Template
//
//  Created by girish lukka on 02/11/2023.
//

import SwiftUI

struct DailyWeatherView: View {
    var day: Daily
    

    var body: some View {
        HStack{
            let formattedDate = DateFormatterUtils.formattedDateWithWeekdayAndDay(from: TimeInterval(day.dt))
            AsyncImage(url: URL(string: "https://openweathermap.org/img/wn/\(day.weather[0].icon)@2x.png"))
            VStack{
                Text(formattedDate)
                    .font(.body) 
                    .padding()
                Text("\(day.weather[0].weatherDescription.rawValue.capitalized)")
                    
            }
            
            Text("\((Int)(day.temp.max))ºC / \((Int)(day.temp.min))ºC")
                .padding(.trailing)
            
        }
            .frame(width: 320, height: 90)
            .listRowBackground(Color.clear)
            .listRowSeparator(.hidden)
            .background(RoundedRectangle(cornerRadius: 25)
            .fill(.white)
            .opacity(0.6)
            .shadow(radius: 10.0))
    }
}

