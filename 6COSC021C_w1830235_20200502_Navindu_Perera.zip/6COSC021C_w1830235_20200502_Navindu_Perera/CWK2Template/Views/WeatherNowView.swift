//
//  WeatherNowView.swift
//  CWK2Template
//
//  Created by girish lukka on 29/10/2023.
//

import SwiftUI

struct WeatherNowView: View {
    @EnvironmentObject var weatherMapViewModel: WeatherMapViewModel
    @State private var isLoading = false
    @State private var temporaryCity = ""
    
    @State private var showAlert = false
    @State private var errorMessage = ""
//    @State var scale = 1.0
    let colors = [Color(#colorLiteral(red: 0.09019608051, green: 0, blue: 0.3019607961, alpha: 1)),Color(#colorLiteral(red: 0.337254902, green: 0.1137254902, blue: 0.7490196078, alpha: 1)),Color(#colorLiteral(red: 0.8549019694, green: 0.250980407, blue: 0.4784313738, alpha: 1)),]
   
    var body: some View {

        ZStack{
            LinearGradient(gradient: Gradient(colors: colors), startPoint: .topLeading, endPoint: .bottomTrailing)
                .ignoresSafeArea()
                .opacity(0.9)
                .background(.ultraThickMaterial)
            
            VStack{
                Spacer()
                HStack{
                    Text("\(weatherMapViewModel.city)")
                }
                .bold()
                .padding(.top,10)
                .font(.system(size: 20))
                .cornerRadius(10)
                .font(.custom("Arial", size: 26))
                .textFieldStyle(RoundedBorderTextFieldStyle())
                .cornerRadius(15)
                .foregroundStyle(.white)
                
                VStack{
                    if let weather = weatherMapViewModel.weatherDataModel?.current.weather.first?.main.rawValue {
                        let imageMapping: [String: String] = [
                            "Clear": "sun.max.fill",
                            "Clouds": "smoke.fill",
                            "Rain": "cloud.drizzle.fill",
                            "Mist": "aqui.low",
                            "Smoke": "smoke",
                            "Haze": "sun.haze.fill",
                            "Dust": "sun.dust.fill",
                            "Fog": "cloud.fog.fill",
                            "Sand": "sun.dust",
                            "Ash": "cloud.sun",
                            "Squall": "wind",
                            "Tornado": "tornado",
                            "Snow": "snowflake",
                            "Drizzle": "cloud.drizzle.fill",
                            "Thunderstorm": "cloud.bolt.rain.fill"
                        ]
                        
                        if let imageName = imageMapping[weather] { 
                            Image(systemName: imageName)
                                    .font(.system(size: 160, weight: .heavy))
                                    .foregroundColor(.white)
                                    .padding(.top,-5)
                                   
                            Text("\(weatherMapViewModel.weatherDataModel?.current.weather[0].weatherDescription.rawValue.capitalized ?? "N/A")")
                                    .monospaced()
                                    .font(.system(size: 30))
                                    .padding(.leading,20)
                                    .padding(.top,-50)
                                    .foregroundColor(.white)
                                    .bold()
                        }
                    }
                    if let forecast = weatherMapViewModel.weatherDataModel {
                        Text("\((Int(round(forecast.current.temp)))) º")
                            .font(.system(size: 80, weight: .bold))
                            .foregroundStyle(.white)
                            .padding(.leading,25)
                            .padding(.top,-40)
                    } else {
                        Text("N/A")
                            .font(.system(size: 25, weight: .medium))
                            .foregroundStyle(.white)
                    }
                }
                Spacer()
                let timestamp = TimeInterval(weatherMapViewModel.weatherDataModel?.current.dt ?? 0)
                let formattedDate = DateFormatterUtils.formattedDateTime(from: timestamp)
                Text(formattedDate)
                    .font(.title)
                    .foregroundStyle(.white)
                    .shadow(color: .black, radius: 1)
                Spacer()
                VStack{
                   
                    HStack{
                       
                        VStack{
                            Image("humidity")
                                .resizable()
                                .aspectRatio(contentMode: .fit)
                                .frame(width: 30, height: 30)
                                .foregroundColor(.blue)
                            if let forecast = weatherMapViewModel.weatherDataModel {
                                Text(" \((Int)(forecast.current.humidity)) %")
                                    .font(.system(size: 25, weight: .medium))
                                    .foregroundStyle(.white)
                            } else {
                                Text(" N/A")
                                    .font(.system(size: 25, weight: .medium))
                                    .foregroundStyle(.white)
                            }
                        }
                        
                        Spacer(minLength: 5)
                        VStack{
                            
                            Image("pressure")
                                .resizable()
                                .aspectRatio(contentMode: .fit)
                                .frame(width: 30, height: 30)
                                .foregroundColor(.blue)
                            if let forecast = weatherMapViewModel.weatherDataModel {
                                Text("\((Int)(forecast.current.pressure)) hPa")
                                    .font(.system(size: 25, weight: .medium))
                                    .foregroundStyle(.white)
                            } else {
                                Text("N/A")
                                    .font(.system(size: 25, weight: .medium))
                                    .foregroundStyle(.white)
                            }
                        }
                        Spacer(minLength:5)
                        VStack{
                            Image("windSpeed")
                                .resizable()
                                .aspectRatio(contentMode: .fit)
                                .frame(width: 30, height: 30)
                                .foregroundColor(.blue)
                               
                            if let forecast = weatherMapViewModel.weatherDataModel {
                                let windDeg = convertDegToCardinal(deg:Int(forecast.current.windDeg) )
                                Text("\((Int)(forecast.current.windSpeed))\(windDeg)")
                                    .font(.system(size: 25, weight: .medium))
                                    .foregroundStyle(.white)
                            } else {
                                Text("N/A")
                                    .font(.system(size: 25, weight: .medium))
                                    .foregroundStyle(.white)
                            }
                        }
                      
                    }
                   
                }
                .padding(.top,20)
                .padding(.horizontal,30)
                .padding(.bottom,20)
                .background(.ultraThinMaterial)
                .cornerRadius(15)
                Spacer(minLength: 5)
                VStack{
                    TextField("Enter New Location", text: $temporaryCity)
                        .onSubmit {
                            let trimmedCity = temporaryCity.trimmingCharacters(in: .whitespaces)

                               guard !trimmedCity.isEmpty else {
                                   // Show an error message for empty or whitespace-only input
                                   showAlert = true
                                   errorMessage = "Please enter a valid city name."
                                   return
                               }

                            let capitalizedCity = trimmedCity
                                       .split(separator: " ")
                                       .map { $0.prefix(1).capitalized + $0.dropFirst().lowercased() }
                                       .joined(separator: " ")
                            Task {
                                do {
                                    // code to process user change of location
                                    weatherMapViewModel.city = capitalizedCity
                                    try await weatherMapViewModel.getCoordinatesForCity()
                                    let newLatitude = weatherMapViewModel.coordinates?.latitude
                                    let newLongitude = weatherMapViewModel.coordinates?.longitude
                                    let _ = try await weatherMapViewModel.loadData(lat: newLatitude ?? 0.0, lon: newLongitude ?? 0.0)
                                } catch  {
                                    print("Error: \(error)")
                                    showAlert = true
                                    errorMessage = "Incorrect City Name! Please check again"
                                    isLoading = false
                                }
                            }
                        }
                        .frame(width:350)
                    Text("Change Location")
                        .foregroundStyle(.white)
                        .monospaced()
                        .font(.system(size: 20))
                }
                .bold()
                .font(.system(size: 20))
                .padding(10)
                .cornerRadius(10)
                .fixedSize()
                .font(.custom("Arial", size: 26))
                .textFieldStyle(RoundedBorderTextFieldStyle())
                .cornerRadius(15)
                
                Spacer()
            }
                   
//                }//VS2
//            }// VS1
        }
        .onAppear(){
            Task {
                do {
                    // code to process user change of location
                    try await weatherMapViewModel.getCoordinatesForCity()
                    let newLatitude = weatherMapViewModel.coordinates?.latitude
                    let newLongitude = weatherMapViewModel.coordinates?.longitude
                    let _ = try await weatherMapViewModel.loadData(lat: newLatitude ?? 0.0, lon: newLongitude ?? 0.0)
                } catch {
                    print("Error: \(error)")
                    isLoading = false
                }
            }
           
        }
        .alert(isPresented: $showAlert) {
            Alert(title: Text("Error"), message: Text(errorMessage), dismissButton: .default(Text("Try Again")))
        }
        
    }
    
}
struct WeatherNowView_Previews: PreviewProvider {
    static var previews: some View {
        WeatherNowView().environmentObject(WeatherMapViewModel())
    }
}
