//
//  TouristPlacesMapView.swift
//  CWK2Template
//
//  Created by girish lukka on 29/10/2023.
//

import Foundation
import SwiftUI
import CoreLocation
import MapKit

struct MainLocationDTO: Codable {
    let places: [Location]
}


struct TouristPlacesMapView: View {
    @EnvironmentObject var weatherMapViewModel: WeatherMapViewModel
    @State var locations: [Location] = []
    @State var  mapRegion = MKCoordinateRegion(center: CLLocationCoordinate2D(latitude: 51.5216871, longitude: -0.1391574), latitudinalMeters: 1000, longitudinalMeters: 1000)
    var coordinates = CLLocationCoordinate2D(latitude: 6.048571410592896, longitude: 80.21811978084509)
    
    let colors = [Color(#colorLiteral(red: 0.09019608051, green: 0, blue: 0.3019607961, alpha: 1)),Color(#colorLiteral(red: 0.337254902, green: 0.1137254902, blue: 0.7490196078, alpha: 1)),Color(#colorLiteral(red: 0.8549019694, green: 0.250980407, blue: 0.4784313738, alpha: 1)),]
    var body: some View {
        NavigationView {
            ZStack{
                LinearGradient(gradient: Gradient(colors: colors), startPoint: .topLeading, endPoint: .bottomTrailing)
                    .ignoresSafeArea()
                    .opacity(0.9)
                    .background(.ultraThickMaterial)
                VStack(spacing: 5) {
                    //if ios version is above IOS17 or IOS 17 to run
                    if #available(iOS 17.0, *) {
                        if weatherMapViewModel.coordinates != nil {
                            VStack(spacing: 10){
                                Map {
                                    if (!locations.contains(where: { $0.cityName == weatherMapViewModel.city })){
                                        MapCircle(center: CLLocationCoordinate2D(latitude: weatherMapViewModel.weatherDataModel?.lat ?? 6.048571410592896, longitude: weatherMapViewModel.weatherDataModel?.lon ?? 80.21811978084509), radius: 1000)
                                            .foregroundStyle(
                                                .red
                                                .opacity(0.20)
                                            )
                                    }
                                    ForEach(locations.filter { $0.cityName == weatherMapViewModel.city }) { location in
                                        Marker(location.name, coordinate: location.coordinates)
                                    }
                                }
                                .cornerRadius(20)
                                .ignoresSafeArea()
                                .frame(height: 400)
                                .mapControls(){
                                    MapUserLocationButton()
                                    MapPitchToggle()
                                }
                            }
                        }
                    }
                    GeometryReader{ _ in
                        ScrollView{
                            ZStack{
                                Image("places")
                                    .resizable()
                                    .scaledToFill()
                                    .edgesIgnoringSafeArea(.all)
                                    .blur(radius: 5)
                                
                                List{
                                    Text("\(weatherMapViewModel.city)")
                                        .monospaced()
                                        .font(.system(size: 30))
                                        .padding(.leading, 115)
                                        .foregroundStyle(.white)
                                        .listRowBackground(Color.clear)
                                        .listRowSeparator(.hidden)
                                        .bold()
                                    if (locations.contains(where: { $0.cityName == weatherMapViewModel.city })){
                                        ForEach(locations){location in
                                            if location.cityName == weatherMapViewModel.city{
                                                HStack{
                                                    Image(location.imageNames[0])
                                                           .resizable()
                                                           .scaledToFit()
                                                           .frame(width: 100, height: 95)
                                                           .cornerRadius(6)
                                                    Text("\(location.name)")
                                                        .padding()
                                                        .font(.system(size: 20))
                                                        .bold()
                                                }
                                                .frame(width: 350, height: 100)
                                                .listRowBackground(Color.clear)
                                                .listRowSeparator(.hidden)
                                                .background(RoundedRectangle(cornerRadius: 25)
                                                .fill(.white)
                                                .opacity(0.4)
                                                .shadow(radius: 10.0))
                                            }
                                        }
                                    }
                                    else{
                                        VStack{
                                            Image(systemName:"exclamationmark.octagon")
                                                .foregroundColor(.white)
                                                .font(.system(size: 50))
                                            Text("Not found")
                                                .foregroundColor(.white)
                                                .monospaced()
                                                .font(.system(size: 30))
                                                .listRowBackground(Color.clear)
                                                .listRowSeparator(.hidden)
                                              
                                        }
                                        .listRowBackground(Color.clear)
                                        .frame(width: 350, height: 125)
                                    }
                                }
                                .listStyle(.plain)
                            }
                            
                        }
                    }
                }
            }
            
        }
        .onAppear {
            // process the loading of tourist places
            loadJasonObject()
            
          
        }
    }
    
    func loadJasonObject(){
        guard let fileURL = Bundle.main.url(forResource: "places", withExtension: "json") else {
            print("could not able to find the file")
            return
        }
        
        do {
            let data = try Data(contentsOf: fileURL)
            let decodeData = try JSONDecoder().decode(MainLocationDTO.self, from: data)
            self.locations = decodeData.places
            
        } catch {
            print("Could not load or decode data")
        }
    }  
}


struct TouristPlacesMapView_Previews: PreviewProvider {
    static var previews: some View {
        TouristPlacesMapView()
            .environmentObject(WeatherMapViewModel())
    }
}
