//
//  WeatherForcastView.swift
//  CWK2Template
//
//  Created by girish lukka on 29/10/2023.
//

import SwiftUI

struct WeatherForecastView: View {
    @EnvironmentObject var weatherMapViewModel: WeatherMapViewModel
    let colors = [Color(#colorLiteral(red: 0.09019608051, green: 0, blue: 0.3019607961, alpha: 1)),Color(#colorLiteral(red: 0.337254902, green: 0.1137254902, blue: 0.7490196078, alpha: 1)),Color(#colorLiteral(red: 0.8549019694, green: 0.250980407, blue: 0.4784313738, alpha: 1)),]
    var body: some View {
        
        NavigationView {
            ZStack{
                LinearGradient(gradient: Gradient(colors: colors), startPoint: .topLeading, endPoint: .bottomTrailing)
                    .ignoresSafeArea()
                    .opacity(0.9)
                    .background(.ultraThickMaterial)
                ScrollView{
                    VStack(spacing: 10) {
                       
                        if let hourlyData = weatherMapViewModel.weatherDataModel?.hourly {
                            Text("Day Forcast")
                                .frame(maxWidth: .infinity, alignment: .leading)
                                .foregroundStyle(.white)
                                .padding(.top,10)
                                .bold()
                            ScrollView(.horizontal, showsIndicators: false) {
                               
                                HStack() {
                                    ForEach(hourlyData) { hour in
                                        HourWeatherView(current: hour)
                                    }
                                }.padding(.top,20)
                                
                            }
                            .frame(height: 250)
                        }
                        Divider()
                            .padding(.horizontal, 16)
                        VStack{
                            Text("Week Forcast")
                                .frame(maxWidth: .infinity, alignment: .leading)
                                .foregroundStyle(.white)
                                .padding(.top,10)
                                .bold()
                                
                            List {
                                ForEach(weatherMapViewModel.weatherDataModel?.daily ?? []) { day in
                                    DailyWeatherView(day: day)
                                }
                            }
                            .listStyle(.plain)
                            .frame(height: 500)
                            .cornerRadius(15)
                        }
                    }
                    .padding(.horizontal, 16)
                }
                .navigationBarTitleDisplayMode(.inline)
                .toolbar {
                    ToolbarItem(placement: .principal) {   VStack{
                                    Text("\(weatherMapViewModel.city)")
                                        .font(.title)
                                        .fontWeight(.bold)
                                        .foregroundStyle(.white)
                                }
                    }
                }.toolbarBackground(.hidden)
            }
           
        }
        
    }
}

struct WeatherForcastView_Previews: PreviewProvider {
    static var previews: some View {
        WeatherForecastView().environmentObject(WeatherMapViewModel())
    }
}
