//
//  NavBar.swift
//  CWK2Template
//
//  Created by girish lukka on 29/10/2023.
//

import SwiftUI

struct NavBar: View {
    var body: some View {
        TabView {
            WeatherNowView()
                .tabItem {
                    Label("City", systemImage: "magnifyingglass")
                }
                .toolbarBackground(.hidden, for:.tabBar)
                .toolbarColorScheme(.dark, for:.tabBar)
            WeatherForecastView()
                .tabItem {
                    Label("Forecast", systemImage: "calendar")
                }
                .toolbarColorScheme(.dark, for: .tabBar)
                .toolbarBackground(.hidden, for:.tabBar)
            TouristPlacesMapView()
                .tabItem {
                    Label("Place Map", systemImage: "map")
                }
                .toolbarBackground(.automatic, for: .tabBar)
//                .toolbarColorScheme(.dark, for: .tabBar)
               
        }
    }
}

struct NavBar_Previews: PreviewProvider {
    static var previews: some View {
        NavBar().environmentObject(WeatherMapViewModel())
    }
}
